import java.util.*;

class EdmondsKarpMaxFlow {
    static final int INF = Integer.MAX_VALUE;

    // BFS to find augmenting path
    static boolean bfs(int[][] residualGraph, int source, int sink, int[] parent) {
        int n = residualGraph.length;
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();
        queue.offer(source);
        visited[source] = true;
        parent[source] = -1;

        while (!queue.isEmpty()) {
            int u = queue.poll();
            for (int v = 0; v < n; v++) {
                if (!visited[v] && residualGraph[u][v] > 0) {
                    queue.offer(v);
                    parent[v] = u;
                    visited[v] = true;
                    if (v == sink)
                        return true;
                }
            }
        }
        return false;
    }

    // Edmonds-Karp algorithm
    static int maxFlow(int[][] graph, int source, int sink) {
        int n = graph.length;
        int[][] residualGraph = new int[n][n];
        for (int i = 0; i < n; i++) {
            System.arraycopy(graph[i], 0, residualGraph[i], 0, n);
        }
        int[] parent = new int[n];
        int maxFlow = 0; // Initialize flow f to 0

        while (bfs(residualGraph, source, sink, parent)) {
            int pathFlow = INF;
            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                pathFlow = Math.min(pathFlow, residualGraph[u][v]);
            }

            for (int v = sink; v != source; v = parent[v]) {
                int u = parent[v];
                residualGraph[u][v] -= pathFlow;
                residualGraph[v][u] += pathFlow;
            }

            maxFlow += pathFlow;
        }
        return maxFlow;
    }

    public static void main(String[] args) {
        int[][] graph = {
              // S   1   2   3   4   T
                {0,  16, 13, 0,  0,  0},  // S
                {0,  0,  10, 12, 0,  0},  // 1
                {0,  0,  0,  4,  14, 0},  // 2
                {0,  0,  9,  0,  9,  20}, // 3
                {0,  0,  0,  0,  0,  4},  // 4
                {0,  0,  0,  0,  0,  0}   // T
        };
        int source = 0, sink = 5;
        System.out.println("The maximum possible flow is " + maxFlow(graph, source, sink));
    }
}

